# MANUFLIX

A Pen created on CodePen.io. Original URL: [https://codepen.io/EMANUELLE-CRISTINA-DE-ALMEIDA-BATISTA/pen/MWNJQVY](https://codepen.io/EMANUELLE-CRISTINA-DE-ALMEIDA-BATISTA/pen/MWNJQVY).

